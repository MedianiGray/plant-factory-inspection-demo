@echo off
chcp 65001 >nul
setlocal
set "P=%~dp0index.html"
if not exist "%P%" (
  echo 没找到 index.html，请把本压缩包完整解压后再运行。
  pause
  exit /b 1
)
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app="file:///%P:\=/%" --window-size=1600,900
  exit /b 0
)
start "" "%P%"
